"""Author-authored synthetic regression; no browser, orders, booking or Spark.
Run: python tests/run_tests.py (from delivery workspace).
"""
import copy
import hashlib
import importlib.util
import json
import sys
import os
from pathlib import Path
from collections import Counter
from jsonschema import Draft202012Validator, FormatChecker

OUT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
def load(path): return json.loads(path.read_text(encoding='utf-8'))
def module(path, name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
mod=module(OUT/'aftercare-logistics/scripts/check_plan.py','logistics_checker')
rows=[]
def test(group,name,condition,detail=''):
    rows.append(dict(group=group,name=name,passed=bool(condition),detail=detail))
def case(n):
    d=OUT/'examples'/f'{n:02d}'
    return tuple(load(d/(name+'.json')) for name in ['request','result','context'])
for spec in load(OUT/'tests/cases.json'):
    q,r,h=case(spec['id']); before=copy.deepcopy((q,r,h))
    report=mod.check(q,r,h)
    ok=(bool(report['errors']) and r['status']=='failed') if spec['expected_input_rejection'] else not report['errors']
    test('authored_business',spec['title'],ok,report['errors'])
    test('read_only',str(spec['id']),before==(q,r,h) and report['automatic_execution_allowed'] is False)
    bad=copy.deepcopy(r); bad['data']['stage']='tracking' if r['data']['stage']!='tracking' else 'prepare_pickup'
    if not spec['expected_input_rejection']:
        test('business_negative','错误阶段-'+str(spec['id']),bool(mod.check(q,bad,h)['errors']))
    test('schema','request/result-'+str(spec['id']),not mod.structural(q,'aftercare-logisticsRequest') and not mod.structural(r,'aftercare-logisticsResult'))

def mutation(name,fn,n=3,group='binding'):
    q,r,h=case(n);fn(q,r,h);report=mod.check(q,r,h)
    test(group,name,bool(report['errors']),report['errors'])
mutation('跨任务',lambda q,r,h:h['registry']['synthetic-orderselection'].update(task_id='other-task'))
mutation('不存在',lambda q,r,h:h['registry'].pop('synthetic-orderselection'))
mutation('旧版本',lambda q,r,h:q['inputs']['order'].update(revision=2))
mutation('过期引用',lambda q,r,h:h['registry']['synthetic-orderselection'].update(current=False))
mutation('无访问权限',lambda q,r,h:h['registry']['synthetic-orderselection'].update(accessible=False))
mutation('错误类型',lambda q,r,h:h['registry']['synthetic-orderselection'].update(kind='OutcomeReport'))
mutation('账户串用',lambda q,r,h:h['registry']['synthetic-orderselection'].update(account_ref='other-account'))
mutation('商品串用',lambda q,r,h:h['registry']['synthetic-orderselection'].update(item_ref='other-item'))
mutation('售后实例串用',lambda q,r,h:h['registry']['synthetic-orderselection'].update(case_ref='other-case'))
mutation('未知证据',lambda q,r,h:r['issues'][0].update(evidence_refs=['nonexistent']))
mutation('返回call串用',lambda q,r,h:r.update(call_id='different-call'))
mutation('返回任务版本错误',lambda q,r,h:r.update(based_on_task_revision=2))
mutation('缺上下文',lambda q,r,h:h.pop('facts'))
mutation('时间无时区',lambda q,r,h:h.update(now='2026-09-27T10:00:00'))
mutation('未来观察',lambda q,r,h:h.update(observed_at='2027-09-27T10:00:00+08:00'))
mutation('地址角色交换',lambda q,r,h:h.update(return_address_ref='synthetic-pickup'))
mutation('原发货地址作为退货地址',lambda q,r,h:h['objects']['synthetic-return'].update(role='order'))
mutation('消息地址冒充平台来源',lambda q,r,h:h['objects']['synthetic-return'].update(source='user_reported'))
mutation('旧地址核对',lambda q,r,h:h['objects']['synthetic-return'].update(current=False))
mutation('地址修改版本未重核',lambda q,r,h:h['objects']['synthetic-return'].update(revision=2))
mutation('地址过期',lambda q,r,h:h['objects']['synthetic-return'].update(expires_at='2026-09-27T09:00:00+08:00'))
mutation('v1地址擅自定义',lambda q,r,h:r['data'].update(address_ref='synthetic-pickup'))
mutation('倒置时间段',lambda q,r,h:h['objects']['synthetic-slot'].update(ends_at='2026-09-28T13:00:00+08:00'))
mutation('无选择就输出时间',lambda q,r,h:r['data'].update(time_slot_ref='synthetic-slot'),7)
mutation('过期时间继续使用',lambda q,r,h:r['data'].update(time_slot_ref='synthetic-slot'),8)
mutation('选择与时间不匹配',lambda q,r,h:h['registry']['synthetic-userdecision']['data'].update(selected_value_ref='synthetic-service'))
mutation('未知费用写零',lambda q,r,h:r['data'].update(fee_known=True,fee={'currency':'CNY','minor_units':0}),9,'fees')
mutation('估算当确定',lambda q,r,h:r['data'].update(fee_known=True,fee={'currency':'CNY','minor_units':1200}),10,'fees')
mutation('运费险当免费',lambda q,r,h:r['data'].update(fee_known=True,fee={'currency':'CNY','minor_units':0}),11,'fees')
mutation('unknown非空金额',lambda q,r,h:r['data'].update(fee={'currency':'CNY','minor_units':1200}),3,'fees')
mutation('错误金额',lambda q,r,h:r['data'].update(fee_known=True,fee={'currency':'CNY','minor_units':1300}),3,'fees')
mutation('原购买运单',lambda q,r,h:r['data'].update(tracking_ref='synthetic-tracking'),15,'tracking')
mutation('格式正确未匹配',lambda q,r,h:r['data'].update(tracking_ref='synthetic-tracking'),16,'tracking')
mutation('OCR未核实',lambda q,r,h:r['data'].update(tracking_ref='synthetic-tracking'),17,'tracking')
mutation('见证称退货但原始记录是购买物流',lambda q,r,h:h['objects']['synthetic-tracking'].update(direction='original'),18,'tracking')
mutation('已发出仍重试',lambda q,r,h:r['issues'][0].update(retryable=True),12,'duplicate_guard')
mutation('交interact绕过缺口',lambda q,r,h:r['data']['next_steps'].append({'intent':'预约','reason':'错误放行','required_evidence':[],'next_skill_hint':'aftercare-interact'}),3,'duplicate_guard')
mutation('待处理动作漏核对',lambda q,r,h:h['registry']['synthetic-tasksnapshot']['data']['pending_execution_refs'].append('synthetic-pending'),3,'duplicate_guard')
mutation('记录不完整',lambda q,r,h:h['facts'].update(history_complete=False),3,'duplicate_guard')
mutation('换call不能重约',lambda q,r,h:(q.update(call_id='new-call'),r.update(call_id='new-call',status='completed',issues=[]),r['data'].update(stage='prepare_pickup')),12,'duplicate_guard')
mutation('页面更新旧时间',lambda q,r,h:h.update(page_revision=2),3,'time_invalidation')
mutation('模式改变',lambda q,r,h:h.update(mode='self'),3,'time_invalidation')
mutation('新会话',lambda q,r,h:h.update(session_epoch=2),3,'time_invalidation')
mutation('任务修订改变',lambda q,r,h:h.update(current_revision=4),3,'time_invalidation')

# Positive fee, exact selected slot, and separate shipping states.
q,r,h=case(3);r['data'].update(fee_known=True,fee=h['fee'],time_slot_ref=h['time_slot_ref'])
test('positive','已核实Money和选择时间仍不执行',not mod.check(q,r,h)['errors'])
for state in ['waybill_created','user_reported_shipped','signed','merchant_received']:
    q,r,h=case(18);h['facts']['shipping_state']=state
    test('tracking',state,not mod.check(q,r,h)['errors'] and mod.check(q,r,h)['hold_external_write'])
q,r,h=case(20);h['facts']['requested_operation']='reschedule'
test('business_positive','改约边界',not mod.check(q,r,h)['errors'])
q,r,h=case(12);h['facts']['action_state']='sent'
test('duplicate_guard','sent同unknown阻断',not mod.check(q,r,h)['errors'])
q,r,h=case(18);r['data']['tracking_ref']=None
test('tracking','不强迫重复安排已寄包裹',not mod.check(q,r,h)['errors'])

for name,fn in [('额外字段',lambda r:r.update(approved=True)),('非法stage',lambda r:r['data'].update(stage='shipped')),('completed带issues',lambda r:r.update(status='completed')),('空data',lambda r:r.update(data=None))]:
    q,r,h=case(3);fn(r);test('schema',name,bool(mod.check(q,r,h)['errors']))

proposal=load(OUT/'candidate/logistics-v2.schema.json')
v=Draft202012Validator(proposal,format_checker=FormatChecker())
test('candidate_only','有效候选',v.is_valid(load(OUT/'candidate/positive.json')))
for name in ['negative-address','negative-fee']:
    test('candidate_only',name,not v.is_valid(load(OUT/'candidate'/f'{name}.json')))

provenance=load(OUT/'aftercare-logistics/references/provenance.json')
for src in provenance['source_files']:
    p=Path(os.environ.get('AFTERCARE_SOURCE_ROOT', 'external-source'))/src['source_id']
    test('source_preservation',p.name,p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==src['sha256'])
central_path=Path(os.environ.get('AFTERCARE_SOURCE_ROOT', 'external-source'))/provenance['source_files'][0]['source_id']
central=load(central_path) if central_path.exists() else None
test('schema','全部派生定义等于中央',central is not None and all(central['$defs'][k]==v for k,v in mod.SCHEMA['$defs'].items()),'requires AFTERCARE_SOURCE_ROOT')

# Actual existing checker modules, STRUCTURAL API ONLY, not real skill execution.
root=Path(os.environ.get('AFTERCARE_SOURCE_ROOT', 'external-source'))
for suffix,skill,script,func in [('-4','interact','validate_plan.py','schema_errors'),('-5','verify','check_report.py','structural')]:
    path=root/('aftercare-'+skill)/'scripts'/script
    if path.exists():
        existing=module(path,'existing_'+skill)
        value=load(OUT/'examples/handoffs'/f'{skill}-request.structure-only.json')
        test('actual_checker_structure_only',skill,not getattr(existing,func)(value,'aftercare-'+skill+'Request'))
    else:
        test('actual_checker_structure_only',skill,False,'source unavailable; no runtime integration claim')

summary={g:{'passed':sum(x['passed'] for x in rows if x['group']==g),'total':sum(x['group']==g for x in rows)} for g in sorted({x['group'] for x in rows})}
report={'scope':'作者合成数据、纯检查器与实际既有校验器的结构入口；不是模型行为或真实平台集成','passed':sum(x['passed'] for x in rows),'total':len(rows),'groups':summary,'results':rows}
(OUT/'tests/results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='results'},ensure_ascii=False,indent=2))
for row in rows:
    if not row['passed']:print('FAIL',row)
raise SystemExit(report['passed']!=report['total'])
